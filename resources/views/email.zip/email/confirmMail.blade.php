<!DOCTYPE html>
<html>
<head>
    <title>zubis inn</title>
</head>
<body>

    {{-- @dd($status) --}}
    {{-- <h1>{{ $status['guest_name'] }}</h1> --}}
    {{-- <p>{{ $status['email'] }}</p> --}}
   
    <p>Your booking is confirmed. Thank you</p>
</body>
</html>